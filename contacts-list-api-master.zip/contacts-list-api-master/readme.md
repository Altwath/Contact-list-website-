# Contacts List API

[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)](https://travis-ci.org/joemccann/dillinger)

Contacts list lets you save all your contacts in one place!

[React app to consume this API](https://github.com/arbaz52/contacts-list)

[Postman Collection](https://www.getpostman.com/collections/748866eb7d2868e517c5)

## How to use

  - Open a command line in this folder
  - Run ```npm install```
  - After it's done installing the libraries, run ```npm start```
  - When the compiler has finished compiling visit [REST API](http://localhost:1337)
